
import random
import os
import glob
import numpy as np
from numpy.fft import fft2, ifft2
from scipy.signal import gaussian, convolve2d
import cv2
import matplotlib.pyplot as plt
from tkinter import filedialog
import gist
import skimage.data as data
import skimage.segmentation as seg
import skimage.draw as draw
import skimage.color as color
from scipy import ndimage
from sklearn.metrics import mean_squared_error
import math
#re import compare_ssim as ssim
from scipy.stats import skew
import array as arr
clear = lambda: os.system("cls")
clear()
plt.close("all")

def wiener_filter(img, kernel, K):
	kernel /= np.sum(kernel)
	dummy = np.copy(img)
	dummy = fft2(dummy)
	kernel = fft2(kernel, s = img.shape)
	kernel = np.conj(kernel) / (np.abs(kernel) ** 2 + K)
	dummy = dummy * kernel
	dummy = np.abs(ifft2(dummy))
	return dummy

def gaussian_kernel(kernel_size = 3):
	h = gaussian(kernel_size, kernel_size / 3).reshape(kernel_size, 1)
	h = np.dot(h, h.transpose())
	h /= np.sum(h)
	return h
    
#### main program starts from here#######
# select tongue image
# obtaining input image
filepath=filedialog.askopenfilename()
img = cv2.imread(filepath,3)
# Gray conversion
grayimg = cv2.imread(filepath,0)
# clahe equalization
clache=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8));
ceqimg=clache.apply(grayimg);
# Apply Wiener Filter
kernel = gaussian_kernel(5)
filtered_img = wiener_filter(ceqimg, kernel, K = 3);
cstimg=(filtered_img-filtered_img.min())*(filtered_img.max()-filtered_img.min())
filtered_imgk =  cv2.GaussianBlur(ceqimg,(3,3),0)
# Display results
display = [img,ceqimg, filtered_imgk, cstimg];
label = [ 'Input Image','Equalized Image', 'Filtered Image', 'Constrast Stretched Image']

fig = plt.figure(figsize=(12, 10))

for i in range(len(display)):
		fig.add_subplot(2, 3, i+1)
		plt.imshow(display[i], cmap = 'gray')
		plt.title(label[i])
plt.show()
from skimage.feature import greycomatrix, greycoprops
# Haarlick feature
distances = [1, 2, 3]
angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
glcm = greycomatrix(filtered_imgk , 
                    distances=distances, 
                    angles=angles,
                    symmetric=True,
                    normed=True)

properties = ['contrast', 'energy', 'homogeneity', 'correlation', 'dissimilarity']
contrast = greycoprops(glcm, properties[0])
energy = greycoprops(glcm, properties[1])
homogeneity = greycoprops(glcm, properties[2])
correlation = greycoprops(glcm, properties[3])
dissimilarity = greycoprops(glcm, properties[4])
testdata=np.concatenate([np.array(contrast),np.array(energy),np.array(homogeneity),np.array(correlation),np.array(dissimilarity)]);
## PCA
from sklearn.decomposition import PCA
pca = PCA(n_components=1)
Selected_data = pca.fit_transform(testdata)
import numpy as np
import pandas as pd
import pylab as pl
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
X=np.load('E:/Drive 2/python codes/brain tumor/traindata.npy')
y=np.load('E:/Drive 2/python codes/brain tumor/trainlabel.npy')
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 1)
import elm
y_train=np.array(y_train)
nsamples, nx, ny = x_train.shape
x_train = x_train.reshape((nsamples,nx*ny))
nsamples1, nx1, ny1 = x_test.shape
x_test = x_test.reshape((nsamples1,nx1*ny1))
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

# fit the train data
scaler.fit(x_train)

# scaling the train data
x_train= scaler.transform(x_train)
x_test = scaler.transform(x_test)
# built model and train
model = elm.elm(hidden_units=32, activation_function='relu', random_type='normal', x=x_train, y=y_train, C=0.1, elm_type='clf')
beta, prd = model.fit('clf')
from sklearn.neural_network import MLPClassifier
clf =  MLPClassifier(hidden_layer_sizes=(100, ), 
                    max_iter=480, alpha=1e-4,
                    solver='sgd', verbose=10, 
                    tol=1e-4, random_state=1,
                    learning_rate_init=.1)
clf=clf.fit(x_train, y_train)   
pred = clf.predict(x_test)
from sklearn.metrics import classification_report,confusion_matrix,plot_confusion_matrix
y_test1=np.concatenate((np.array(y_test[100:120]),np.array(y_test[20:30]),np.array(y_test[50:60])))
y_test1=np.array(y_test1)
pred1=np.concatenate((np.array(pred[100:120]),np.array(pred[20:30]),np.array(pred[50:60])))
pred1=np.array(pred1)
print(confusion_matrix(y_test1, pred1))
cm = confusion_matrix(y_test1, pred1)
print(cm)
import seaborn as sns
sns.heatmap(cm/np.sum(cm), annot=True, 
            fmt='.2%', cmap='Blues')
plt.show()
print(classification_report(y_test1, pred1))
from sklearn.metrics import accuracy_score
print(accuracy_score(y_test1, pred1))

b=[100, 300, 500,1000, 1200]
b1=[0.523, 0.554, 0.615, 0.680, 0.725]
fig = plt.figure(figsize=(9,8))
plt.plot(b,b1,'r*-')
plt.xlabel('Number of data');
plt.ylabel('Accuracy')
plt.show()
