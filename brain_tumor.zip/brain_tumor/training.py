import random
import os
import glob
import numpy as np
from numpy.fft import fft2, ifft2
from scipy.signal import gaussian, convolve2d
import cv2
import matplotlib.pyplot as plt
from tkinter import filedialog
import gist
import skimage.data as data
import skimage.segmentation as seg
import skimage.draw as draw
import skimage.color as color
from scipy import ndimage
from sklearn.metrics import mean_squared_error
import math
#re import compare_ssim as ssim
from scipy.stats import skew
import array as arr
clear = lambda: os.system("cls")
clear()
plt.close("all")

def wiener_filter(img, kernel, K):
	kernel /= np.sum(kernel)
	dummy = np.copy(img)
	dummy = fft2(dummy)
	kernel = fft2(kernel, s = img.shape)
	kernel = np.conj(kernel) / (np.abs(kernel) ** 2 + K)
	dummy = dummy * kernel
	dummy = np.abs(ifft2(dummy))
	return dummy

def gaussian_kernel(kernel_size = 3):
	h = gaussian(kernel_size, kernel_size / 3).reshape(kernel_size, 1)
	h = np.dot(h, h.transpose())
	h /= np.sum(h)
	return h
#### main program starts from here#######
# obtaining input image
totalfeat=[]

path = glob.glob("E:/Drive 2/python codes/brain tumor/*.jpg")
traindata = []
for imgn in path:
        img = cv2.imread(imgn,3)
        # Gray conversion
        grayimg = cv2.imread(imgn,0)
# clahe equalization
        clache=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8));
        ceqimg=clache.apply(grayimg);
# Apply Wiener Filter
        kernel = gaussian_kernel(5)
        filtered_img = wiener_filter(ceqimg, kernel, K = 3);
        cstimg=(filtered_img-filtered_img.min())*(filtered_img.max()-filtered_img.min())
        filtered_imgk =  cv2.GaussianBlur(ceqimg,(3,3),0)
        from skimage.feature import greycomatrix, greycoprops
# Haarlick feature
        distances = [1, 2, 3]
        angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
        glcm = greycomatrix(filtered_imgk , 
                    distances=distances, 
                    angles=angles,
                    symmetric=True,
                    normed=True)

        properties = ['contrast', 'energy', 'homogeneity', 'correlation', 'dissimilarity']
        contrast = greycoprops(glcm, properties[0])
        energy = greycoprops(glcm, properties[1])
        homogeneity = greycoprops(glcm, properties[2])
        correlation = greycoprops(glcm, properties[3])
        dissimilarity = greycoprops(glcm, properties[4])
## PCA
        from sklearn.decomposition import PCA
        pca = PCA(n_components=1)
        testdata=np.concatenate([np.array(contrast),np.array(energy),np.array(homogeneity),np.array(correlation),np.array(dissimilarity)]);
        Selected_data = pca.fit_transform(testdata)
        traindata.append(Selected_data)
trainfeat=np.array(traindata)
labl=[]
np.save('traindata.npy', trainfeat)

