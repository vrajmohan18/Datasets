import numpy as np
labl=[]
for ik in range(0,300):
 labl.append([0])
for ik in range(301,601):
 labl.append([1])
for ik in range(602,902):
 labl.append([2])
for ik in range(903,1203):
 labl.append([3])
labl=np.array(labl)
np.save('trainlabel.npy', labl)





